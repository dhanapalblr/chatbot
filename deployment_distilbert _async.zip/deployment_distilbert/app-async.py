from flask import Flask
from string import Template
from flask import Flask, render_template, request
from flask import jsonify
import asyncio
import warnings
warnings.filterwarnings("ignore")


from util7D_async import *

app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False

@app.route('/utterance',methods=['POST'])
def utterance():
    if request.method=='POST':
        m = request.get_json()
        text=m['utterance']
    
    async def main():
        divs=[]
        for i in ['iris','hiri']: # add the domain names here
            divs.append(asyncio.create_task(pred(text,i)))
        return await asyncio.gather(*[i for i in divs])
    
    output = asyncio.run(main())
    r=[]
    for i in output:
        for j in i:
            r.append(j)


    res={'intentList':sorted(r,key=lambda x: x['confidence'],reverse=True)}
    
    return jsonify(res)

if __name__ == "__main__":
	#decide what port to run the app in
	port = int(os.environ.get('PORT', 5001))
	#run the app locally on the givn port
	app.run(host='0.0.0.0', port=port,debug=True)
	#optional if we want to run in debugging mode
	#app.run(debug=True)
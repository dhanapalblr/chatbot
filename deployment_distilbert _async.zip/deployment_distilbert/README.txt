
How to run the deployment code:
1. Replace the all 3 h5 files with hiri, lcs, and iris model files
2. Replace the 3 train full cleaned files with the iris,hiri, and lcs files
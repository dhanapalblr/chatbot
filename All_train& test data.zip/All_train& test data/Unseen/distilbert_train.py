import os
import nltk
import pandas as pd
import numpy as np
import tensorflow as tf
import pandas as pd
import json
import gc
import os
import numpy as np
from transformers import DistilBertTokenizer
from transformers import TFDistilBertForSequenceClassification
df = pd.read_excel("lcs_train_may_cleaned.xlsx",sheet_name="Train",usecols=['utterance', 'intent1','intent'])

num_classes=len(df.intent1.unique())

from transformers import DistilBertTokenizer, TFDistilBertModel, DistilBertConfig
DistilBert_tokenizer = DistilBertTokenizer.from_pretrained("/nlv/TrainBertDhana/distilbert-base-uncased")
DistilBert_model = TFDistilBertForSequenceClassification.from_pretrained("/nlv/TrainBertDhana/distilbert-base-uncased",num_labels=num_classes, from_pt=True)
sentences=df['utterance']
labels=df['intent1']
input_ids=[]
attention_masks=[]
for sent in sentences:
    DistilBert_inp=DistilBert_tokenizer.encode_plus(str(sent),add_special_tokens = True,max_length =64,pad_to_max_length = True,return_attention_mask = True)
    input_ids.append(DistilBert_inp['input_ids'])
    attention_masks.append(DistilBert_inp['attention_mask'])
input_ids=np.asarray(input_ids)
attention_masks=np.array(attention_masks)
labels=np.array(labels)
len(input_ids),len(attention_masks),len(labels)
import pickle
print('Preparing the pickle file.....')
pickle_inp_path='DistilBert_inp.pkl'
pickle_mask_path='DistilBert_mask.pkl'
pickle_label_path='DistilBert.pkl'
pickle.dump((input_ids),open(pickle_inp_path,'wb'))
pickle.dump((attention_masks),open(pickle_mask_path,'wb'))
pickle.dump((labels),open(pickle_label_path,'wb'))
print('Pickle files saved as ',pickle_inp_path,pickle_mask_path,pickle_label_path)
print('Loading the saved pickle files..')
input_ids=pickle.load(open(pickle_inp_path, 'rb'))
attention_masks=pickle.load(open(pickle_mask_path, 'rb'))
labels=pickle.load(open(pickle_label_path, 'rb'))
print('Input shape {} Attention mask shape {} Input label shape {}'.format(input_ids.shape,attention_masks.shape,labels.shape))
from sklearn.model_selection import train_test_split
train_inp,val_inp,train_label,val_label,train_mask,val_mask=train_test_split(input_ids,labels,attention_masks,test_size=0.01)
print('Train inp shape {} Val input shape {}\nTrain label shape {} Val label shape {}\nTrain attention mask shape {} Val attention mask shape {}'.format(train_inp.shape,val_inp.shape,train_label.shape,val_label.shape,train_mask.shape,val_mask.shape))
import tensorflow as tf
import pandas as pd
from sklearn.model_selection import train_test_split
import numpy as np
import re
import unicodedata
import nltk
from nltk.corpus import stopwords
import keras
from tqdm import tqdm
import pickle
from keras.models import Model
import keras.backend as K
from sklearn.metrics import confusion_matrix,f1_score,classification_report
import matplotlib.pyplot as plt
from keras.callbacks import ModelCheckpoint
import itertools
from keras.models import load_model
from sklearn.utils import shuffle
import torch
from transformers import DistilBertTokenizer, TFDistilBertModel, DistilBertConfig
log_dir='tensorboard_data/tb_DistilBert'
model_save_path='DistilBert_lcs_model.h5'
callbacks = [tf.keras.callbacks.ModelCheckpoint(filepath=model_save_path,save_weights_only=True,monitor='val_loss',mode='min',save_best_only=True),keras.callbacks.TensorBoard(log_dir=log_dir)]
loss = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True)
metric = tf.keras.metrics.SparseCategoricalAccuracy('accuracy')
optimizer = tf.keras.optimizers.Adam(learning_rate=2e-5,epsilon=1e-08)

DistilBert_model.compile(loss=loss,optimizer=optimizer,metrics=[metric])
history=DistilBert_model.fit([train_inp,train_mask],train_label,batch_size=32,epochs=30,validation_data=([val_inp,val_mask],val_label),callbacks=callbacks)
model_save_path='DistilBert_modelh.h5'
trained_model = TFDistilBertForSequenceClassification.from_pretrained("/nlv/TrainBertDhana/distilbert-base-uncased",num_labels=num_classes, from_pt=True)
trained_model.compile(loss=loss,optimizer=optimizer, metrics=[metric])
trained_model.load_weights(model_save_path)
preds = trained_model.predict([val_inp,val_mask],batch_size=32)
pred_labels = preds[0].argmax(axis=1)
f1 = f1_score(val_label,pred_labels,average="weighted")

print('F1 score',f1)
print('Classification Report')
print(classification_report(val_label,pred_labels))
print('Training and saving built model.....')
trained_model.evaluate([val_inp,val_mask],batch_size=32)

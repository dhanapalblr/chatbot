loss = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True)
metric = tf.keras.metrics.SparseCategoricalAccuracy('accuracy')
optimizer = tf.keras.optimizers.Adam(learning_rate=2e-5,epsilon=1e-08)

df = pd.read_excel('/nlv/ForThiya/TFXLMRoberta/data_hindi_tamil_consolidated.xlsx',sheet_name="Tamil",usecols=["Utterance Tamil","intent1"]) # Change path to your download location
num_classes=len(df.intent1.unique())

XLMRoberta_tokenizer = XLMRobertaTokenizer.from_pretrained("/nlv/ForThiya/TFXLMRoberta/tf-xlm-roberta-base")
XLMRoberta_model = TFXLMRobertaForSequenceClassification.from_pretrained('/nlv/ForThiya/TFXLMRoberta/tf-xlm-roberta-base',num_labels=num_classes)

model_save_path='/nlv/ForThiya/TFXLMRoberta/TamilModel/XLMRoberta_modelt.h5'
trained_model = TFXLMRobertaForSequenceClassification.from_pretrained('/nlv/ForThiya/TFXLMRoberta/tf-xlm-roberta-base',num_labels=num_classes)

trained_model.compile(loss=loss,optimizer=optimizer, metrics=[metric])
trained_model.load_weights(model_save_path)

model_save_path='/nlv/ForThiya/TFXLMRoberta/HindiModel/XLMRoberta_modelh.h5'
trained_model1 = TFXLMRobertaForSequenceClassification.from_pretrained('/nlv/ForThiya/TFXLMRoberta/tf-xlm-roberta-base',num_labels=num_classes)

trained_model1.compile(loss=loss,optimizer=optimizer, metrics=[metric])
trained_model1.load_weights(model_save_path)

df = pd.read_excel('/nlv/ForThiya/TFXLMRoberta/data_hindi_tamil_consolidated.xlsx',sheet_name="Tamil",usecols=["Utterance Tamil","intent1"]) # Change path to your download location
    num_classes=len(df.intent1.unique())
    sentences=pd.Series(np.array([text])) 
    input_ids=[]
    attention_masks=[]
    for sent in sentences:
        XLMRoberta_inp=XLMRoberta_tokenizer.encode_plus(sent,add_special_tokens = True,max_length =64,pad_to_max_length = True,return_attention_mask = True)
        input_ids.append(XLMRoberta_inp['input_ids'])
        attention_masks.append(XLMRoberta_inp['attention_mask'])
    input_ids=np.asarray(input_ids)
    attention_masks=np.array(attention_masks)

    preds = trained_model.predict([input_ids,attention_masks],batch_size=32)
    print(preds[0])
    # pred_labels=tf.argmax(preds[0][0], axis=1)
    pred_labels = tf.argmax(preds[0],axis=1)
    print(pred_labels)
    pred_prob = tf.nn.softmax(tf.convert_to_tensor(preds[0]))
    print(pred_prob)
    pred_prob_top,classes = tf.nn.top_k(pred_prob, 4)
    top_prob1=pred_prob_top[0][0]
    top_prob2=pred_prob_top[0][1]
    top_prob3=pred_prob_top[0][2]
    top_prob4=pred_prob_top[0][3]
    top_class1=classes[0][0]
    top_class2=classes[0][1]
    top_class3=classes[0][2]
    top_class4=classes[0][3]
    # print(pred_prob_top,classes)
    print(top_prob1,top_prob2,top_prob3,top_class1,top_class2,top_class3)
    # pred_labels=tf.argmax(preds[0][0], axis=1)
    pred_labels = tf.argmax(preds[0],axis=1)
    print(pred_labels)

    dmap=pd.read_excel("/nlv/ForThiya/TFXLMRoberta/data_hindi_tamil_consolidated.xlsx",sheet_name="mapping")
    d= dict([(i,a) for i, a in zip(dmap.mapping, dmap.intent)])
    print(d)
    print(int(pred_labels))
    print(d[int(pred_labels)])
    print(d[int(top_class1)])
    print(d[int(top_class2)])
    print(d[int(top_class3)])
    return d[int(top_class1)],d[int(top_class2)],d[int(top_class3)],d[int(top_class4)],top_prob1.numpy(),top_prob2.numpy(),top_prob3.numpy(),top_prob4.numpy()
import pandas as pd
import os
import numpy as np
from nltk.tokenize import word_tokenize
from nltk import pos_tag
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.preprocessing import LabelEncoder
from collections import defaultdict
from nltk.corpus import wordnet as wn
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn import model_selection, naive_bayes, svm
from sklearn.metrics import accuracy_score


## We'll be training a SVM model to predict the domain based on the utterance
## Take all the test datasets and combine to create the train data for the domain predition

raw=pd.concat([pd.read_csv(i) for i in os.listdir() if i.startswith('All_models_test')])
domain_map=raw[['utterance','domain']]
domain_map.rename(columns={'domain':'initial_domain'},inplace=True)

np.random.seed(500)
domain_map.dropna(subset=['utterance'],inplace=True)
domain_map['utterance']=domain_map['utterance'].str.lower()

Train_X, Test_X, Train_Y, Test_Y = model_selection.train_test_split(domain_map['utterance'],domain_map['initial_domain'],test_size=0.1)

Encoder = LabelEncoder()
Train_Y = Encoder.fit_transform(Train_Y)
Test_Y = Encoder.transform(Test_Y)

Tfidf_vect = TfidfVectorizer(max_features=5000)
Tfidf_vect.fit(domain_map['utterance'])
Train_X_Tfidf = Tfidf_vect.transform(Train_X)
Test_X_Tfidf = Tfidf_vect.transform(Test_X)

# Classifier - Algorithm - SVM
# fit the training dataset on the classifier
SVM = svm.SVC(C=1.0, kernel='linear', degree=3, gamma='auto')
SVM.fit(Train_X_Tfidf,Train_Y)
# predict the labels on validation dataset
predictions_SVM = SVM.predict(Test_X_Tfidf)
# Use accuracy_score function to get the accuracy
print("SVM Accuracy Score -> ",accuracy_score(predictions_SVM, Test_Y)*100)

## Read the output file from the all domain test

df=pd.read_excel('All_outputs_combined.xlsx', engine='openpyxl')[['utterance','intent','intent1','intent_predicted','confidence','domain','Order of confidence scores']]

# take only the rows with top confidence scores

df=df[df['Order of confidence scores']==1]

# Make the prediction for the domain from the trained model above

df['predicted_domain']=Encoder.inverse_transform(SVM.predict(Tfidf_vect.transform(df['utterance'])))

df1=df[df['domain']==df['predicted_domain']].drop_duplicates('utterance')  ## take the only rows where predicted domain matches the model domains

## Calculate the accuracy score

df1['match']=df1['intent']==df1['intent_predicted']

k=df1['match'].value_counts()

print('The confidence score is : {}'.format(k[True]/(k[True]+k[False])))

df1.to_excel('output.xlsx',index=None)





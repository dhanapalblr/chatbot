import os
import tensorflow as tf
import pandas as pd
from sklearn.model_selection import train_test_split
import numpy as np
import re
import unicodedata
import nltk
from nltk.corpus import stopwords
import keras
from tqdm import tqdm
import pickle
from keras.models import Model
import keras.backend as K
from sklearn.metrics import confusion_matrix,f1_score,classification_report
import matplotlib.pyplot as plt
from keras.callbacks import ModelCheckpoint
import itertools
from keras.models import load_model
from sklearn.utils import shuffle
import torch
from transformers import DistilBertTokenizer, TFDistilBertModel, DistilBertConfig
from transformers import TFDistilBertForSequenceClassification
import torch.nn.functional as nnf
import time
import torch.nn as nn
import pandas as pd

def pred(text,TRAINING_FILE,MODEL_PATH):
  BERT_PATH='distilbert-base-uncased'
  df=pd.read_excel(TRAINING_FILE)
  num_classes=len(df.intent1.unique())
  d= dict([(i,a) for i, a in zip(df.intent1, df.intent)])
  tokenizer = DistilBertTokenizer.from_pretrained(BERT_PATH, do_lower_case=True)
  loss = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True)
  metric = tf.keras.metrics.SparseCategoricalAccuracy('accuracy')
  optimizer = tf.keras.optimizers.Adam(learning_rate=2e-5,epsilon=1e-08)
  MODEL = TFDistilBertForSequenceClassification.from_pretrained(BERT_PATH,num_labels=num_classes)
  MODEL.compile(loss=loss,optimizer=optimizer, metrics=[metric])
  MODEL.load_weights(MODEL_PATH)
  maxindx,predictions,maxindx1,maxindx2,maxindx3,maxindx4,predictions1,predictions2,predictions3,predictions4=[],[],[],[],[],[],[],[],[],[]
  top_p1,top_p2,top_p3,top_class1,top_class2,top_class3=[],[],[],[],[],[]

  DistilBert_inp=tokenizer.encode_plus(text,add_special_tokens = True,max_length =64,pad_to_max_length = True,return_attention_mask = True)
  input_ids=DistilBert_inp['input_ids']
  attention_masks=DistilBert_inp['attention_mask']
  input_ids=np.asarray(input_ids).reshape(-1,64)
  attention_masks=np.array(attention_masks).reshape(-1,64)
  outputs = MODEL.predict([input_ids,attention_masks],batch_size=32)
  maxidx = outputs[0].argmax(axis=1)
  maxindx.append(int(maxidx))

  predictions.append(d[int(maxidx)])
  prob = nnf.softmax(torch.tensor(outputs[0]),dim=1)
  top_p, top_class = prob.topk(3, dim = 1)

  top_p1.append(float(top_p[0][0]))
  top_p2.append(float(top_p[0][1]))
  top_p3.append(float(top_p[0][2]))
  top_class1.append(int(top_class[0][0]))
  top_class2.append(int(top_class[0][1]))
  top_class3.append(int(top_class[0][2]))

  predictions1.append(d[int(top_class[0][0])])
  predictions2.append(d[int(top_class[0][1])])
  predictions3.append(d[int(top_class[0][2])])

  return {"intentList":
          [ {"intent":predictions1[0],
             "confidence":top_p1[0]},
           {"intent":predictions2[0],
            "confidence":top_p2[0]},
           {"intent":predictions3[0],
            "confidence":top_p3[0]}]}
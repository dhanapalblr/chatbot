
# !pip install simpletransformers
# !pip install swifter

import os
import nltk
import pandas as pd
import numpy as np
import pickle
from simpletransformers.classification import ClassificationModel
import torch

# from google.colab import drive
# drive.mount('/content/drive')
# curentdirectory='/content/drive/MyDrive/Work/Dan/Simpletransformers_model/'
# os.chdir(curentdirectory)

with open('7iris_model.pkl','rb') as f:
  model=pickle.load(f)

## Prediction and formating the output

df=pd.read_excel('7iris_train_cleaned.xlsx')
map_df=df[['intent','intent1']].drop_duplicates()
eval_df=pd.read_excel('7iris_test_cleaned.xlsx').rename(columns={'utterance':'text','intent1':'label'})[['text','label']]
preds=model.predict(eval_df['text'])
import torch.nn.functional as nnf
prob=nnf.softmax(torch.tensor(preds[1]),dim=1)
top_p, top_class = prob.topk(3, dim = 1)
top_class=top_class.cpu().detach().numpy()
top_p=top_p.cpu().detach().numpy()

tc=pd.DataFrame(top_class).reset_index().melt(id_vars='index').set_index('index').rename(columns={'value':'predicted_intent1'}).drop('variable',axis=1)
tp=pd.DataFrame(top_p).reset_index().melt(id_vars='index').set_index('index').rename(columns={'variable':'Order of Confidence Score','value':'confidence'})
conf=pd.concat([tc,tp],axis=1)

eval_df=eval_df.join(conf)
eval_df.rename(columns={'text':'utterance','label':'intent1'},inplace=True)
eval_df=pd.merge(pd.merge(eval_df,map_df,on='intent1',how='left'),map_df.rename(columns={'intent1':'predicted_intent1','intent':'intent_predicted'}),on='predicted_intent1',how='left')#.rename(columns={})

eval_df['Order of Confidence Score']=eval_df['Order of Confidence Score']+1
eval_df=eval_df[['utterance', 'intent', 'intent1', 'intent_predicted',
       'Order of Confidence Score', 'confidence']]
eval_df['domain']='iris'
eval_df['Matched']=eval_df['intent']==eval_df['intent_predicted']
eval_df.to_excel('7iris_test_output.xlsx',index=None)

# Calculate the accuracy

from sklearn.metrics import accuracy_score
eval_df1=eval_df[eval_df['Order of Confidence Score']==1]
print('The accuracy is : {}'.format(accuracy_score(eval_df1['intent'], eval_df1['intent_predicted'])))

## Read the ngrams list and find the ngrams in utterance and multiply weights in confidence if ngram is found.

ng=pd.read_csv('ngrams_list.csv')  # read the ngrams list
ng['domain']=ng['domain'].astype(str).str.lower() # make the ngram and domain columns lowercase
ng['ngram']=ng['ngram'].astype(str).str.lower()
ng=ng[(ng['ngram']!='nan')&(ng['ngram'].str.len()>1) & (~ng['ngram'].str.contains('could'))].dropna(subset=['ngram'])
ng=ng[ng['domain']!='cctr']
ng=ng[ng.language=='EN'].dropna()

def fun(row):
    d={1:1.25,2:1.5,3:1.75,0:1,4:1,5:1} # multiply with 1.25 if length of ngram is 1, with 1.5 if length is 2 and 1.75 if its 3.
    l=[]
    n=[]
    try:
        ng1=ng.copy().drop_duplicates(subset=['ngram'])  # select the corresponding domain in the ngram
        for i in ng1['ngram']:
            if str(i) in str(row['utterance']):
                l.append(len(str(i).split()))
                n.append(str(i))

        l1=max(l)   # take the maximum of the lengths of the ngrams so that if multiple ngrams are found prefer with largest length.
        n1=n[np.argmax(l)] # take the matched ngram
    except:
        l1=0
        n1='None'  # put none if ngram is not found in the utterance
    row['confidence_updated']=row['confidence']*d[l1]
    row['ngram_found']=n1
    return row

import swifter
eval_df=eval_df.swifter.apply(lambda x: fun(x),axis=1)
eval_df.to_excel('7iris_test_output.xlsx',index=None)
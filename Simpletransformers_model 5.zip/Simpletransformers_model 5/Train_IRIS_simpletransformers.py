import os
import nltk
import pandas as pd
import numpy as np
from simpletransformers.classification import ClassificationModel
import torch

# !pip install simpletransformers
# !pip install swifter

## if running on google drive

# from google.colab import drive
# drive.mount('/content/drive')
# curentdirectory='/content/drive/MyDrive/Work/Dan/Simpletransformers_model/'
# os.chdir(curentdirectory)

## Read the iris train data and rename columns

df=pd.read_excel('7iris_train_cleaned.xlsx')
map_df=df[['intent','intent1']].drop_duplicates()
train_df=pd.read_excel('7iris_train_cleaned.xlsx').rename(columns={'utterance':'text','intent1':'label'})[['text','label']]

# Create the weights for the intents based on frequency

wt=[]
cls = len(pd.Categorical(train_df["label"].unique()))
for i in range(0,cls):
  len_wt = train_df.query('label == @i').shape[0]
  weight = train_df.shape[0] / (cls * len_wt)
  wt.append(weight)

# Model training

args = {"output_dir": "outputs/","cache_dir": "cache_dir/","fp16": True,"fp16_opt_level": "O1","max_seq_length": 128,
        "train_batch_size": 8,"gradient_accumulation_steps": 1,"eval_batch_size": 8,"num_train_epochs": 20,"weight_decay": 0,
        "learning_rate": 4e-5,"adam_epsilon": 1e-8,"warmup_ratio": 0.06,"warmup_steps": 0,"max_grad_norm": 1.0,
        "logging_steps": 50,"save_steps": 2000,"overwrite_output_dir": True,"reprocess_input_data": False,
        "evaluate_during_training": False,"save_model_every_epoch":False,"n_gpu": 1,
}
model = ClassificationModel("distilbert","distilbert-base-uncased",num_labels=cls,weight=wt,args=args,use_cuda=True,)
print('Starting the training')
model.train_model(train_df)

import pickle
with open('7iris_model.pkl','wb') as f:
  pickle.dump(model,f)
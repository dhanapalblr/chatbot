import pandas as pd
import numpy as np
import swifter,re

# read all the excel files
import os
domains=["data","easre","hiri","ibgpdts","iris", "lcs", "riskgov"]

files_name=[i for i in  os.listdir() if i.startswith('7')]
df_l=[]
for i in files_name:
    df=pd.read_excel(i,sheet_name=None)
    df=df[list(df.keys())[1]]
    df=df[df['utterance'].notna()]   # here i drop the row containing Empty utterance in data
    for dm in domains:
        df['domain']=dm
        df_l.append(df.copy())

df=pd.concat(df_l)



# read ngrams
ng=pd.read_csv('ngrams_list.csv')  # read the ngrams list
ng['domain']=ng['domain'].astype(str).str.lower() # make the ngram and domain columns lowercase
ng['ngram']=ng['ngram'].astype(str).str.lower()

## Following function will search for the ngram in the utterance and then multiply the weight in top_p1, top_p2 and top_p3 columns if found.

domainngram = {dom:ng[ng['domain'] == dom].drop_duplicates(subset=['ngram'])["ngram"].values  for dom in domains}  # make the dict with ngram for each domain
def fun(row):
    d={1:1.25,2:1.5,3:1.75,0:1,4:1,5:1} # multiply with 1.25 if length of ngram is 1, with 1.5 if length is 2 and 1.75 if its 3.
    l,n=[],[]
    try:
        strUtterence=str(row['utterance']).split()
        ngrams=domainngram[row['domain']]    #select the ngram corresponding domain
        for ng in ngrams:
            if str(ng) in strUtterence:  # here we search the ngram words
                l.append(len(str(ng).split()))
                n.append(str(ng))

        l1=max(l)   # take the maximum of the lengths of the ngrams so that if multiple ngrams are found prefer with largest length.
        n1=n[np.argmax(l)] # take the matched ngram
    except:
        l1=0
        n1='None'  # put none if ngram is not found in the utterance
    row['top_p1_updated']=row['top_p1']*d[l1]
    row['top_p2_updated']=row['top_p2']*d[l1]
    row['top_p3_updated']=row['top_p3']*d[l1]
    row['ngram_found']=n1
    return row


if __name__=="__main__":
    dataframe = df.swifter.apply(lambda x: fun(x), axis=1)
    commoncolums=['utterance', 'intent', 'intent1','intent_prediction','confidence','updated_confidence','domain','ngram']
    colums=['utterance', 'intent', 'intent1','predictions1','top_p1','top_p1_updated','domain','ngram_found']
    dataframe1=dataframe[colums]
    dataframe1.columns=commoncolums
    dataframe1.insert(7, 'order of confidence', 1)
    colums = ['utterance','intent','intent1','predictions2','top_p2','top_p2_updated','domain','ngram_found']
    dataframe2 = dataframe[colums]
    dataframe2.columns = commoncolums
    dataframe2.insert(7, 'order of confidence', 2)
    colums = ['utterance','intent','intent1','predictions3','top_p3','top_p3_updated','domain','ngram_found']
    dataframe3 = dataframe[colums]
    dataframe3.columns = commoncolums
    dataframe3.insert(7, 'order of confidence', 3)
    dataframe=pd.concat([dataframe1,dataframe2,dataframe3])
    dataframe.sort_values(by=['utterance','domain'],inplace=True)
    dataframe.to_excel('output.xlsx',index=None)


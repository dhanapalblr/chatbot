
How to run the deployment code:
1. open the terminal and go to current folder
2. run the following command - "python app.py"
3. The app will be hosted on the given server and port in the app.py
import pandas as pd
import os
import numpy as np

df=pd.read_excel('All_outputs_combined.xlsx', engine='openpyxl')[['utterance','intent','intent1','intent_predicted','confidence','domain','Order of confidence scores']]

raw=pd.concat([pd.read_csv(i) for i in os.listdir() if i.startswith('All_models_test')])

domain_map=raw[['utterance','domain']]

domain_map.rename(columns={'domain':'initial_domain'},inplace=True)
domain_map['utterance']=domain_map['utterance'].str.split()

dd=domain_map.explode('utterance')

dd1=dd.groupby('utterance')['initial_domain'].apply(lambda x: x.value_counts().index[0]).reset_index()

ng=pd.merge(dd1,dd,how='left',on='utterance').drop_duplicates()
ng=ng.rename(columns={'utterance':'token','initial_domain_y':'domain'})[['token','domain']]

import swifter
df=df[df['Order of confidence scores']==1]

def fun(x):
    for ii in range(len(ng)):
        i=ng.iloc[ii]['token']
        if str(i) in str(x['utterance']).split():
            x['token_found']=str(i)
            x['domain_token']=ng.iloc[ii]['domain']
            break
    return x

print('The code run started .....')

df1=df.apply(lambda x: fun(x),axis=1)

df1['domain_token']=np.where(df1['domain_token'].isnull(),df1['domain'],df1['domain_token'])


df2=df1[df1['domain']==df1['domain_token']]


df2['match']=df2['intent']==df2['intent_predicted']

k=df2['match'].value_counts()

print('Accuracy: {}'.format(k[True]/(k[True]+k[False])))

df2.to_excel('output.xlsx',index=None)

